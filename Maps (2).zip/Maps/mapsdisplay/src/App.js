import { Map, GoogleApiWrapper } from "google-maps-react";
import { Component } from "react";

class MapContainer extends Component {
  componentDidMount() {
    console.log("Map loaded");
  }

  render() {
    return (
      <Map
        google={this.props.google}
        style={{ width: "100%", height: "100%" }}
        zoom={20}
        initialCenter={{
          lat: 18.520430,
          lng: 73.856743
        }}
      />
    );
  }
}

export default GoogleApiWrapper({
  apiKey: "AIzaSyAVK2J4mi1vUAYJUXF5-Jq_n_s39LeUbCQ"
})(MapContainer)