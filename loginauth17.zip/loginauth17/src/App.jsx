import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import React, { useState, useEffect } from "react";
import { LoadScript } from "@react-google-maps/api";
import Layout from "./components/Layout";
import Home from "./components/Home/home";
import PersonalInfo from "./components/PersonalInfo";
import AddressDetails from "./components/AddAddress";
import SelectDisplayMap from "./components/SelectDisplayMap/SelectDisplayMap";
// import AddressForm from "./components/AddressSelector";

import Login from "./components/Login";

const GOOGLE_MAPS_API_KEY = "AIzaSyAVK2J4mi1vUAYJUXF5-Jq_n_s39LeUbCQ";

const App = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    const storedAuth = localStorage.getItem("isAuthenticated");
    if (storedAuth === "true") {
      setIsAuthenticated(true);
    }
  }, [isAuthenticated]);

  const handleAuthChange = (status) => {
    setIsAuthenticated(status);
    localStorage.setItem("isAuthenticated", status);
  };

  return (
    <LoadScript googleMapsApiKey={GOOGLE_MAPS_API_KEY} libraries={["places"]}>
      <Router>
        <Routes>
          {/* Public Route (Login) */}
          <Route path="/login" element={<Login setIsAuthenticated={handleAuthChange} />} />

          {/* Protected Routes Wrapped in Layout */}
          {/* {isAuthenticated ? (
            <Route path="/" element={<Layout setIsAuthenticated={handleAuthChange} />}>
              <Route path="home" element={<Home />} />
              <Route path="personal-info" element={<PersonalInfo />} />
            </Route>
          ) : (
            <Route path="*" element={<Navigate to="/login" />} />
          )} */}
            <Route 
            path="/" 
            element={isAuthenticated ? <Layout isAuthenticated={isAuthenticated} setIsAuthenticated={handleAuthChange} /> : <Navigate to="/login" />}
          >
            <Route path="home" element={<Home />} />
            <Route path="personal-info" element={<PersonalInfo />} />
            <Route path="/select-display-map" element={<SelectDisplayMap /> }/>
            <Route path="*" element={<Navigate to={isAuthenticated ? "/home" : "/login"} />} />
          </Route>
        </Routes>
      </Router>
    </LoadScript>
  );
};

export default App;
