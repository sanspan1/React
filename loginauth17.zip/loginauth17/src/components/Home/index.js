import Home from "./Home/home"

export default Home