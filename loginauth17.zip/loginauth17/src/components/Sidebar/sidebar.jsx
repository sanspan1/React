
import "./sidebar.css";
import { Link } from "react-router-dom";


const Sidebar = () => {

    return (
        <div className="sidebar">
            <ul>
                <li><Link to="/home">Home</Link></li>
                <li ><Link to="/personal-info">Personal Information</Link></li>
                {/* <li><Link to=   "/address-details">Add-details</Link></li> */}
            </ul>

        </div>
    );
};

export default Sidebar;
