import React from 'react'
import AddressDetails from '../AddAddress'

const SelectDisplayMap = () => {
  return (
    <div>
        <AddressDetails />
    </div>
  )
}

export default SelectDisplayMap