import { useState } from "react";
import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";
import AutocompleteInput from "../AutoCompleteInput"; // Import the existing Autocomplete component
import "./AddAddress.css";

const AddressDetails = () => {
    const { register, handleSubmit, setValue, formState: { errors } } = useForm();
    const [address, setAddress] = useState("");
    const navigate = useNavigate();

    const onSubmit = (data) => {
        console.log("Address Submitted:", data);
        alert("Address saved successfully!");
        navigate(-1); // Go back to the previous page (PersonalInfo form)
    };

    return (
        <div className="address-form-container">
            <h2>Address Details</h2>
            <form onSubmit={handleSubmit(onSubmit)}>
                {/* Address Input using Autocomplete */}
                {/* <label>Enter Address:</label> */}
                <AutocompleteInput
                    value={address}
                    onChange={(newValue) => setAddress(newValue)}
                    onSelect={(selectedAddress) => {
                        setAddress(selectedAddress);
                        setValue("address", selectedAddress, { shouldValidate: true });
                    }}
                />
                {errors.address && <p className="error">{errors.address.message}</p>}

                {/* Submit Button */}
                <button type="submit" className="save-button">Save Address</button>

                {/* Cancel Button */}
                <button type="button" className="cancel-button" onClick={() => navigate(-1)}>
                    Cancel
                </button>
            </form>
        </div>
    );
};

export default AddressDetails;
