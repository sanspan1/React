import Maps from "./map";

export default Maps