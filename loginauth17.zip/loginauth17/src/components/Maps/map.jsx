import React, { useEffect, useRef } from "react";
import { Loader } from "@googlemaps/js-api-loader";
import img from './searceinc_logo.jpg';
import './maps.css';

const Maps = () => {
    const mapRef = useRef(null); // 🔹 Reference to map container

    useEffect(() => {
        const loader = new Loader({
            apiKey: "AIzaSyAVK2J4mi1vUAYJUXF5-Jq_n_s39LeUbCQ"
        });

        loader.load().then(async () => {
            const { Map } = await google.maps.importLibrary("maps");
            const { AdvancedMarkerElement } = await google.maps.importLibrary("marker");

            // Ensure the map initializes correctly
            if (mapRef.current) {
                let map = new Map(mapRef.current, {
                    center: { lat: 18.58003260351618, lng: 73.7381763553059 },
                    zoom: 15,
                    mapId: "DEMO_MAP_ID"
                });

                // Custom image for marker
                const image = document.createElement("img");
                image.src = img;
                image.width = 100;
                image.height = 100;
                image.style.borderRadius = "50%";
                image.style.border = "2px solid blue";

                const marker = new AdvancedMarkerElement({
                    map,
                    position: { lat: 18.58003260351618, lng: 73.7381763553059 },
                    content: image,
                });

                new google.maps.Circle({
                    center: { lat: 18.58003260351618, lng: 73.7381763553059 },
                    radius: 80,
                    map: map,
                    strokeColor: "#FF0000",
                    strokeOpacity: 0.8,
                    strokeWeight: 2,
                    fillColor: "#FF0000",
                    fillOpacity: 0.35,
                });

                // Smooth zoom effect
                // setTimeout(() => {
                //     setInterval(() => {
                //         let zoom = map.getZoom();
                //         if (zoom <= 18) {
                //             map.setZoom(zoom + 1);
                //         }
                //     }, 200);
                // }, 2000);
            }
        });
    }, []);

    return <div id="map" ref={mapRef}></div>;  // 🔹 Use ref instead of document.getElementById
};

export default Maps;
