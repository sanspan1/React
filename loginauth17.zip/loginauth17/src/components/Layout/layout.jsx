import { Outlet } from "react-router-dom";
import Sidebar from "../Sidebar/sidebar";
import Header from "../Header/header";

const Layout = ({ isAuthenticated, setIsAuthenticated }) => {
    return (
        <div className="layout">
            <Sidebar />
            <div className="content">
                {/* Pass setIsAuthenticated to Header */}
                <Header setIsAuthenticated={setIsAuthenticated} />
                <main>
                    <Outlet />
                </main>
            </div>
        </div>
    );
};

export default Layout;