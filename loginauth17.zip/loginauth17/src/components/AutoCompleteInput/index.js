import AutocompleteInput from "./AutoCompleteInput";

export default AutocompleteInput;