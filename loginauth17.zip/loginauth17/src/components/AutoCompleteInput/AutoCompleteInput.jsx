import { useEffect, useState } from "react";
import './AutoCompleteInput.css'

const AutocompleteInput = ({ value, onChange, onSelect }) => {
    const [predictions, setPredictions] = useState([]);
    const [query, setQuery] = useState(value || "");
    const [shouldRefetch, setShouldRefetch] = useState(false);

    useEffect(() => {
        if (!window.google || !window.google.maps) return;
        if (!shouldRefetch) return;

        const autocompleteService = new window.google.maps.places.AutocompleteService();

        if (query.length > 2) {
            autocompleteService.getPlacePredictions({ input: query }, (results, status) => {
                if (status === window.google.maps.places.PlacesServiceStatus.OK) {
                    setPredictions(results);
                }
            });
        } else {
            setPredictions([]);
        }

        setShouldRefetch(false);
    }, [shouldRefetch]);

    const handleSelectAddress = (address) => {
        setQuery(address);
        setPredictions([]);
        onSelect(address); // Pass the selected address to the parent component
    };

    return (
        <div>
            <input
                type="text"
                value={query}
                onChange={(e) => {
                    setQuery(e.target.value);
                    onChange(e.target.value); // Update parent state
                    setShouldRefetch(true);
                }}
                placeholder="Enter your address"
                style={{ width: "100%", padding: "8px" }}
            />
            {predictions.length > 0 && (
                <ul className="autocomplete-suggestions">
                    {predictions.map((place) => (
                        <li key={place.place_id} onClick={() => handleSelectAddress(place.description)}>
                            {place.description}
                        </li>
                    ))}
                </ul>
            )}
        </div>
    );
};

export default AutocompleteInput;
