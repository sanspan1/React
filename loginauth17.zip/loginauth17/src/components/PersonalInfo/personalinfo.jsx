// import { useEffect, useState } from "react";
// import { useForm } from "react-hook-form";
// import { Link } from "react-router-dom";
// import { DevTool } from "@hookform/devtools";
// import "./personalinfo.css";

// const PersonalInfo = () => {
//     const {
//         register,
//         handleSubmit,
//         setValue,
//         reset,
//         formState: { errors },
//         control
//     } = useForm();
    
//     const [predictions, setPredictions] = useState([]);
//     const [query, setQuery] = useState("");
//     const [shouldRefetch, setShouldRefetch] = useState(false)

//     useEffect(() => {
//         // Ensure Google API is available
//         if (!window.google || !window.google.maps) return;
//         if (!shouldRefetch) return

//         const autocompleteService = new window.google.maps.places.AutocompleteService();

//         if (query.length > 2) {
//             autocompleteService.getPlacePredictions(
//                 { input: query },
//                 (results, status) => {
//                     if (status === window.google.maps.places.PlacesServiceStatus.OK) {
//                         setPredictions(results);
//                     }
//                 }
//             );
//         } else {
//             setPredictions([]);
//         }

//         setShouldRefetch(false)
//     }, [shouldRefetch]);

//     const handleSelectAddress = (address) => {
//         setValue("address", address, { shouldValidate: true });
//         setQuery(address);
//         setPredictions([]);
//     };

//     const onSubmit = (data) => {
//         console.log("Form Data Submitted:", data);
//         localStorage.setItem("personalInfo", JSON.stringify(data));
//         console.log(localStorage.getItem("personalInfo"));
//         alert("Form submitted successfully!");
//         setQuery("");
//         reset();

//     };


//     return (
//         <div className="form-container">
//             <h2>Personal Information</h2>
//             <form onSubmit={handleSubmit(onSubmit)}>
//                 {/* Name */}
//                 <label>Name:</label>
//                 <input
//                     type="text"
//                     {...register("name", {
//                         required: "Name is required",
//                         minLength: { value: 2, message: "Name must be at least 2 characters long" }
//                     })}
//                 />
//                 {errors.name && <p className="error">{errors.name.message}</p>}

//                 {/* Birthday */}
//                 <label>Birthday:</label>
//                 <input type="date" {...register("birthday", { required: "Birthday is required" })} />
//                 {errors.birthday && <p className="error">{errors.birthday.message}</p>}

//                 {/* Gender */}
//                 <label>Gender:</label>
//                 <select {...register("gender", { required: "Gender is required" })}>
//                     <option value="">Select Gender</option>
//                     <option value="male">Male</option>
//                     <option value="female">Female</option>
//                     <option value="other">Other</option>
//                 </select>
//                 {errors.gender && <p className="error">{errors.gender.message}</p>}

//                 {/* Email */}
//                 <label>Email:</label>
//                 <input
//                     type="email"
//                     {...register("email", {
//                         required: "Email is required",
//                         pattern: { value: /^\S+@\S+$/i, message: "Invalid email format" }
//                     })}
//                 />
//                 {errors.email && <p className="error">{errors.email.message}</p>}

//                 {/* Phone */}
//                 <label>Phone:</label>
//                 <input
//                     type="tel"
//                     {...register("phone", {
//                         required: "Phone number is required",
//                         pattern: { value: /^[0-9]{10,15}$/, message: "Enter a valid phone number (10-15 digits)" }
//                     })}
//                 />
//                 {errors.phone && <p className="error">{errors.phone.message}</p>}

//                 {/* Address with Google Autocomplete */}
//                 <label>Address:</label>
//                 <input
//                     type="text"
//                     {...register("address", { required: "Address is required" })}
//                     placeholder="Enter your address"
//                     value={query}
//                     onChange={(e) => { setQuery(e.target.value); setShouldRefetch(true) }}
//                     style={{ width: "100%", padding: "8px" }}
//                 />
//                 {errors.address && <p className="error">{errors.address.message}</p>}

//                 {/* Address Suggestions */}
//                 {predictions.length > 0 && (
//                     <ul className="autocomplete-suggestions">
//                         {predictions.map((place) => (
//                             <li key={place.place_id} onClick={() => handleSelectAddress(place.description)}>
//                                 {place.description}
//                             </li>
//                         ))}
//                     </ul>
//                 )}
//                 <button>Enter Address</button>

//                 <label>Address:</label>
//                 <Link to="/enter-address">
//                     <button type="button" style={{ marginTop: "10px" }}>Enter Address</button>
//                 </Link>

//                 {/* Submit Button */}
//                 <button type="submit">Submit</button>
//             </form>
//             {/* <DevTool control={control} /> */}
//         </div>
//     );
// };

// export default PersonalInfo;


//v2

// import { useEffect, useState } from "react";
// import { useForm } from "react-hook-form";
// import { Link } from "react-router-dom";
// import "./personalinfo.css";

// const PersonalInfo = () => {
//     const {
//         register,
//         handleSubmit,
//         setValue,
//         reset,
//         formState: { errors }
//     } = useForm();
    
//     const [address, setAddress] = useState("");

//     const onSubmit = (data) => {
//         const formData = {
//             ...data,
//             address: address
//         };
//         console.log("Form Data Submitted:", formData);
//         localStorage.setItem("personalInfo", JSON.stringify(formData));
//         alert("Form submitted successfully!");
//         setAddress("");
//         reset();
//     };

//     return (
//         <div className="form-container">
//             <h2>Personal Information</h2>
//             <form onSubmit={handleSubmit(onSubmit)}>
//                 {/* Name */}
//                 <div className="form-group">
//                     <label>Full Name:</label>
//                     <input
//                         type="text"
//                         {...register("name", {
//                             required: "Name is required",
//                             minLength: { value: 2, message: "Name must be at least 2 characters long" }
//                         })}
//                         placeholder="Enter your full name"
//                     />
//                     {errors.name && <p className="error">{errors.name.message}</p>}
//                 </div>

//                 {/* Birthday */}
//                 <div className="form-group">
//                     <label>Date of Birth:</label>
//                     <input 
//                         type="date" 
//                         {...register("birthday", { required: "Date of birth is required" })} 
//                     />
//                     {errors.birthday && <p className="error">{errors.birthday.message}</p>}
//                 </div>

//                 {/* Gender */}
//                 <div className="form-group">
//                     <label>Gender:</label>
//                     <div className="radio-group">
//                         <label className="radio-label">
//                             <input
//                                 type="radio"
//                                 value="male"
//                                 {...register("gender", { required: "Gender is required" })}
//                             />
//                             Male
//                         </label>
//                         <label className="radio-label">
//                             <input
//                                 type="radio"
//                                 value="female"
//                                 {...register("gender", { required: "Gender is required" })}
//                             />
//                             Female
//                         </label>
//                         <label className="radio-label">
//                             <input
//                                 type="radio"
//                                 value="other"
//                                 {...register("gender", { required: "Gender is required" })}
//                             />
//                             Other
//                         </label>
//                     </div>
//                     {errors.gender && <p className="error">{errors.gender.message}</p>}
//                 </div>

//                 {/* Email */}
//                 <div className="form-group">
//                     <label>Email:</label>
//                     <input
//                         type="email"
//                         {...register("email", {
//                             required: "Email is required",
//                             pattern: { value: /^\S+@\S+$/i, message: "Invalid email format" }
//                         })}
//                         placeholder="Enter your email"
//                     />
//                     {errors.email && <p className="error">{errors.email.message}</p>}
//                 </div>

//                 {/* Phone */}
//                 <div className="form-group">
//                     <label>Phone Number:</label>
//                     <input
//                         type="tel"
//                         {...register("phone", {
//                             required: "Phone number is required",
//                             pattern: { value: /^[0-9]{10,15}$/, message: "Enter a valid phone number (10-15 digits)" }
//                         })}
//                         placeholder="Enter your phone number"
//                     />
//                     {errors.phone && <p className="error">{errors.phone.message}</p>}
//                 </div>

//                 {/* Nationality */}
//                 <div className="form-group">
//                     <label>Nationality:</label>
//                     <input
//                         type="text"
//                         {...register("nationality", { required: "Nationality is required" })}
//                         placeholder="Enter your nationality"
//                     />
//                     {errors.nationality && <p className="error">{errors.nationality.message}</p>}
//                 </div>

//                 {/* Address Display */}
//                 <div className="form-group">
//                     <label>Address:</label>
//                     <div className="address-container">
//                         <input
//                             type="text"
//                             value={address}
//                             readOnly
//                             placeholder="No address selected"
//                             className="address-input"
//                         />
//                         <Link to="/enter-address" className="address-button">
//                             Enter Address
//                         </Link>
//                     </div>
//                 </div>

//                 {/* Submit Button */}
//                 <button type="submit" className="submit-button">Submit</button>
//             </form>
//         </div>
//     );
// };

// export default PersonalInfo;

//v3 autocomplete as a component

import { useForm } from "react-hook-form";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./personalinfo.css";

const PersonalInfo = () => {
    const {
        register,
        handleSubmit,
        setValue,
        reset,
        formState: { errors }
    } = useForm();
    const navigate = useNavigate();

    const [address, setAddress] = useState("");

    const onSubmit = (data) => {
        console.log("Form Data Submitted:", data);
        localStorage.setItem("personalInfo", JSON.stringify(data));
        alert("Form submitted successfully!");
        reset();
        setAddress("");
    };

    return (
        <div className="form-container">
            <h2>Personal Information</h2>
            <form onSubmit={handleSubmit(onSubmit)}>
                {/* Name */}
                <label>Name:</label>
                <input
                    type="text"
                    {...register("name", {
                        required: "Name is required",
                        minLength: { value: 2, message: "Name must be at least 2 characters long" }
                    })}
                />
                {errors.name && <p className="error">{errors.name.message}</p>}

                {/* Birthday */}
                <label>Birthday:</label>
                <input type="date" {...register("birthday", { required: "Birthday is required" })} />
                {errors.birthday && <p className="error">{errors.birthday.message}</p>}

                {/* Gender (Radio Buttons) */}
                {/* <label>Gender:</label>
                <div className="radio-group">
                    <label>
                        <input type="radio" value="male" {...register("gender", { required: "Gender is required" })} />
                        Male
                    </label>
                    <label>
                        <input type="radio" value="female" {...register("gender", { required: "Gender is required" })} />
                        Female
                    </label>
                    <label>
                        <input type="radio" value="other" {...register("gender", { required: "Gender is required" })} />
                        Other
                    </label>
                </div>
                {errors.gender && <p className="error">{errors.gender.message}</p>} */}

                {/* Gender (Radio Buttons) */}
<label>Gender:</label>
<div className="radio-group">
    <label className="radio-option">
        <input type="radio" value="male" {...register("gender", { required: "Gender is required" })} />
        Male
    </label>
    <label className="radio-option">
        <input type="radio" value="female" {...register("gender", { required: "Gender is required" })} />
        Female
    </label>
    <label className="radio-option">
        <input type="radio" value="other" {...register("gender", { required: "Gender is required" })} />
        Other
    </label>
</div>
{errors.gender && <p className="error">{errors.gender.message}</p>}


                {/* Email */}
                <label>Email:</label>
                <input
                    type="email"
                    {...register("email", {
                        required: "Email is required",
                        pattern: { value: /^\S+@\S+$/i, message: "Invalid email format" }
                    })}
                />
                {errors.email && <p className="error">{errors.email.message}</p>}

                {/* Phone */}
                <label>Phone:</label>
                <input
                    type="tel"
                    {...register("phone", {
                        required: "Phone number is required",
                        pattern: { value: /^[0-9]{10,15}$/, message: "Enter a valid phone number (10-15 digits)" }
                    })}
                />
                {errors.phone && <p className="error">{errors.phone.message}</p>}

                {/* Address with Google Autocomplete */}
                <label>Address:</label>
                {/* <button>Add Address</button> */}
                {/* <AutocompleteInput
                    value={address}
                    onChange={(newValue) => setAddress(newValue)}
                    onSelect={(selectedAddress) => {
                        setAddress(selectedAddress);
                        setValue("address", selectedAddress, { shouldValidate: true });
                    }}
                />
                {errors.address && <p className="error">{errors.address.message}</p>} */}

                <button
                    type="button"
                    className="navigate-button"
                    onClick={() => navigate("/select-display-map")} // Replace with your route
                >
                    Add Address
                </button>
                <br />
                {/* <br /> */}

                {/* Submit Button */}
                <button type="submit">Submit</button>
            </form>
        </div>
    );
};

export default PersonalInfo;
