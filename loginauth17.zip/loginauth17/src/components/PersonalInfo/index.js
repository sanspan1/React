import PersonalInfo from "./personalinfo";

export default PersonalInfo