import { useForm } from "react-hook-form";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import './login.css';
import { DevTool } from "@hookform/devtools";

const Login = ({ setIsAuthenticated }) => {
    const { register, handleSubmit, control } = useForm();
    const navigate = useNavigate();

    const onSubmit = async (data) => {
        try {
            const response = await axios.post("http://localhost:3000/login", {
                username: data.username,
                password: data.password,
            });

            if (response.data.success) {
                setIsAuthenticated(true);
                navigate("/home");
            } else {
                alert("Invalid credentials");
            }
        } catch (error) {
            alert("Login failed: " + (error.response?.data?.message || error.message));
        }
    };

    return (
        <div className="login-container">
            <div className="login-box">
                <h2>Login Page</h2>
                <form onSubmit={handleSubmit(onSubmit)}>
                    <input {...register("username", { required: true })} placeholder="Username" />
                    <br />
                    <input type="password" {...register("password", { required: true })} placeholder="Password" />
                    <br />
                    <button type="submit">Login</button>
                </form>
            </div>
            <DevTool control={control} />
        </div>
    );
};

export default Login;