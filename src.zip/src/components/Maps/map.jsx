
import "./maps.css";
import { useEffect } from "react";
import { Loader } from "@googlemaps/js-api-loader";

const Map = () => {

    useEffect(() => {
        console.log("logged")
        const loader = new Loader({
            apiKey: "AIzaSyAVK2J4mi1vUAYJUXF5-Jq_n_s39LeUbCQ",
            version: "weekly",
        });

        loader.load().then(async () => {
            const { Map, Polyline, Polygon } = await google.maps.importLibrary("maps");
            const { AdvancedMarkerElement } = await google.maps.importLibrary("marker");

            console.log(document.getElementById("map"))
            let map = new Map(document.getElementById("map"), {
                center: { lat: 18.58026396275932, lng: 73.73806906755271 },
                zoom: 10,
                mapId: "DEMO_MAP_ID"
            });

            let polyline = new Polyline({
                path: [{ lat: 18.58026396275932, lng: 73.73806906755271 }, { lat: 18.58645706408861, lng: 73.7378407508487 }],
                map
            });

            let marker = new AdvancedMarkerElement({
                position: { lat: 18.58026396275932, lng: 73.73806906755271 },
                map
            });

            let polygon = new Polygon({
                paths: [{ lat: 18.58026396275932, lng: 73.73806906755271 }, { lat: 18.578818253840677, lng: 73.73436539632988 }, { lat: 18.574220460677935, lng: 73.7374630906234 }],
                map
            });
        });
    }, []);
    return (
        <div id="map"></div>
    );
};

export default Map;
