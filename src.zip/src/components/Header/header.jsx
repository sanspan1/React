import logo from "./img.jpg"
import "./header.css";

const Header = () => {
    return (
        <div className="header" >
            <img src={logo} height={"30px"} width={"60px"}></img>
        </div>
    );
};

export default Header;
