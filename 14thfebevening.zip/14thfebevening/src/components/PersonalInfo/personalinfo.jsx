import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { DevTool } from "@hookform/devtools";
import "./personalinfo.css";

const PersonalInfo = () => {
    const {
        register,
        handleSubmit,
        setValue,
        reset,
        formState: { errors },
        control
    } = useForm();



    // const {
    //     register,
    //     handleSubmit,
    //     setValue,
    //     formState: { errors },
    //     control
    // } = useForm(); 

    // const [autocomplete, setAutocomplete] = useState(null);

    // const handlePlaceSelect = () => {
    //     if (autocomplete) {
    //         const place = autocomplete.getPlace();
    //         if (place.formatted_address) {
    //             setValue("address", place.formatted_address, { shouldValidate: true });
    //         }
    //     }
    // };

    // const onSubmit = (data) => {
    //     console.log("Form Data Submitted:", data);
    //     alert("Form submitted successfully!");
    //     reset()
    // };

    const [predictions, setPredictions] = useState([]);
    const [query, setQuery] = useState("");
    const [shouldRefetch, setShouldRefetch] = useState(false)

    useEffect(() => {
        // Ensure Google API is available
        if (!window.google || !window.google.maps) return;
        if (!shouldRefetch) return

        const autocompleteService = new window.google.maps.places.AutocompleteService();

        if (query.length > 2) {
            autocompleteService.getPlacePredictions(
                { input: query },
                (results, status) => {
                    if (status === window.google.maps.places.PlacesServiceStatus.OK) {
                        setPredictions(results);
                    }
                }
            );
        } else {
            setPredictions([]);
        }

        setShouldRefetch(false)
    }, [shouldRefetch]);

    const handleSelectAddress = (address) => {
        setValue("address", address, { shouldValidate: true });
        setQuery(address);
        setPredictions([]);
    };

    const onSubmit = (data) => {
        console.log("Form Data Submitted:", data);
        localStorage.setItem("personalInfo", JSON.stringify(data));
        console.log(localStorage.getItem("personalInfo"));
        alert("Form submitted successfully!");
        setQuery("");
        reset();

    };


    return (
        <div className="form-container">
            <h2>Personal Information</h2>
            <form onSubmit={handleSubmit(onSubmit)}>
                {/* Name */}
                <label>Name:</label>
                <input
                    type="text"
                    {...register("name", {
                        required: "Name is required",
                        minLength: { value: 2, message: "Name must be at least 2 characters long" }
                    })}
                />
                {errors.name && <p className="error">{errors.name.message}</p>}

                {/* Birthday */}
                <label>Birthday:</label>
                <input type="date" {...register("birthday", { required: "Birthday is required" })} />
                {errors.birthday && <p className="error">{errors.birthday.message}</p>}

                {/* Gender */}
                <label>Gender:</label>
                <select {...register("gender", { required: "Gender is required" })}>
                    <option value="">Select Gender</option>
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                    <option value="other">Other</option>
                </select>
                {errors.gender && <p className="error">{errors.gender.message}</p>}

                {/* Email */}
                <label>Email:</label>
                <input
                    type="email"
                    {...register("email", {
                        required: "Email is required",
                        pattern: { value: /^\S+@\S+$/i, message: "Invalid email format" }
                    })}
                />
                {errors.email && <p className="error">{errors.email.message}</p>}

                {/* Phone */}
                <label>Phone:</label>
                <input
                    type="tel"
                    {...register("phone", {
                        required: "Phone number is required",
                        pattern: { value: /^[0-9]{10,15}$/, message: "Enter a valid phone number (10-15 digits)" }
                    })}
                />
                {errors.phone && <p className="error">{errors.phone.message}</p>}

                {/* Address with Google Autocomplete */}
                <label>Address:</label>
                <input
                    type="text"
                    {...register("address", { required: "Address is required" })}
                    placeholder="Enter your address"
                    value={query}
                    onChange={(e) => { setQuery(e.target.value); setShouldRefetch(true) }}
                    style={{ width: "100%", padding: "8px" }}
                />
                {errors.address && <p className="error">{errors.address.message}</p>}

                {/* Address Suggestions */}
                {predictions.length > 0 && (
                    <ul className="autocomplete-suggestions">
                        {predictions.map((place) => (
                            <li key={place.place_id} onClick={() => handleSelectAddress(place.description)}>
                                {place.description}
                            </li>
                        ))}
                    </ul>
                )}

                {/* Submit Button */}
                <button type="submit">Submit</button>
            </form>
            <DevTool control={control} />
        </div>
    );
};

export default PersonalInfo;
