import React, { useState, useEffect } from "react";
import { useLocation } from "./LocationContext";
import "./AddressAutocomplete.css";

const AddressAutocomplete = () => {
    const [predictions, setPredictions] = useState([]);
    const [query, setQuery] = useState("");
    const [shouldRefetch, setShouldRefetch] = useState(false);
    const { coordinates, updateCoordinates, updateAddress } = useLocation();

    useEffect(() => {
        if (!window.google || !window.google.maps) return;
        if (!shouldRefetch) return;

        const autocompleteService = new window.google.maps.places.AutocompleteService();

        if (query.length > 2) {
            autocompleteService.getPlacePredictions(
                { input: query },
                (results, status) => {
                    if (status === window.google.maps.places.PlacesServiceStatus.OK) {
                        setPredictions(results);
                    }
                }
            );
        } else {
            setPredictions([]);
        }

        setShouldRefetch(false);
    }, [shouldRefetch]);

    const handleSelectAddress = (address) => {
        setQuery(address);
        updateAddress(address);
        setPredictions([]);

        // Geocode the selected address
        const geocoder = new window.google.maps.Geocoder();
        geocoder.geocode({ address: address }, (results, status) => {
            if (status === "OK" && results[0]) {
                const { lat, lng } = results[0].geometry.location;
                updateCoordinates(lat(), lng());
            }
        });
    };

    return (
        <div className="address-container">
            <label className="address-label">Enter Address:</label>
            <input
                type="text"
                value={query}
                onChange={(e) => {
                    setQuery(e.target.value);
                    setShouldRefetch(true);
                }}
                className="address-input"
                placeholder="Type your address..."
            />
            {predictions.length > 0 && (
                <ul className="predictions-list">
                    {predictions.map((prediction) => (
                        <li
                            key={prediction.place_id}
                            className="prediction-item"
                            onClick={() => handleSelectAddress(prediction.description)}
                        >
                            {prediction.description}
                        </li>
                    ))}
                </ul>
            )}
            <div className="coordinate-container">
                <label className="coordinate-label">Latitude:</label>
                <div className="coordinate-value">
                    {coordinates.lat.toFixed(5)}
                </div>
            </div>
            <div className="coordinate-container">
                <label className="coordinate-label">Longitude:</label>
                <div className="coordinate-value">
                    {coordinates.lng.toFixed(5)}
                </div>
            </div>
        </div>
    );
};

export default AddressAutocomplete;