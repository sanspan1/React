import { GoogleMap, LoadScript } from "@react-google-maps/api";
import { useState, useRef, useEffect } from "react";
import { useLocation } from "./LocationContext";
import styles from "./GoogleMapsCenteredMarker.module.css";

const GoogleMapsCenteredMarker = () => {
    const mapRef = useRef(null);
    const { coordinates, updateCoordinates, address } = useLocation();

    useEffect(() => {
        if (mapRef.current && coordinates) {
            mapRef.current.panTo(coordinates);
        }
    }, [coordinates]);

    const handleCenterChanged = () => {
        if (mapRef.current) {
            const newCenter = mapRef.current.getCenter();
            const newPosition = {
                lat: newCenter.lat(),
                lng: newCenter.lng(),
            };
            updateCoordinates(newPosition.lat, newPosition.lng);

            // Reverse geocoding when marker is dragged
            const geocoder = new window.google.maps.Geocoder();
            geocoder.geocode({ location: newPosition }, (results, status) => {
                if (status === "OK" && results[0]) {
                    // Update address in context
                    updateAddress(results[0].formatted_address);
                }
            });
        }
    };

    return (
        <LoadScript googleMapsApiKey="YOUR_GOOGLE_MAPS_API_KEY">
            <div className={styles.mapContainer}>
                <GoogleMap
                    mapContainerClassName={styles.map}
                    center={coordinates}
                    zoom={13}
                    onLoad={(map) => {
                        mapRef.current = map;
                    }}
                    onCenterChanged={handleCenterChanged}
                    options={{ draggable: true }}
                />

                {/* Fixed Center Marker */}
                <div className={styles.markerContainer}>
                    <img
                        src="https://maps.gstatic.com/mapfiles/api-3/images/spotlight-poi2_hdpi.png"
                        alt="Marker"
                        className={styles.markerImage}
                    />
                </div>

                {/* Display Coordinates */}
                <div className={styles.coordinatesDisplay}>
                    Lat: {coordinates.lat.toFixed(5)}, Lng: {coordinates.lng.toFixed(5)}
                </div>
            </div>
        </LoadScript>
    );
};

export default GoogleMapsCenteredMarker;