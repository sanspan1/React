import { Outlet } from "react-router-dom";
import Sidebar from "../Sidebar/sidebar";
import Header from "../Header/header";

const Layout = () => {
    return (
        <div className="layout">
            <Sidebar />
            <div className="content">
                <Header />
                <main>
                    <Outlet />
                </main>
            </div>
        </div>
    );
};

export default Layout;
