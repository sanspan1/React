import React, { useEffect, useRef } from "react";
import { Loader } from "@googlemaps/js-api-loader";
import './maps.css'

const GoogleMap = () => {

  const loader = new Loader({
    apiKey: "AIzaSyAVK2J4mi1vUAYJUXF5-Jq_n_s39LeUbCQ"
  });

  loader.load().then(async () => {
    const { Map, Polyline, Polygon } = await google.maps.importLibrary("maps");
    const { AdvancedMarkerElement } = await google.maps.importLibrary("marker");
    // const result = await google.maps.importLibrary("places");

    let map = new Map(document.getElementById("map"), {
      center: { lat: 18.58026396275932, lng: 73.73806906755271 },
      zoom: 10,
      mapId: "DEMO_MAP_ID"
    });

    let polyline = new Polyline({
      path: [{ lat: 18.58026396275932, lng: 73.73806906755271 }, { lat: 18.58645706408861, lng: 73.7378407508487 }],
      map
    })

    let marker = new AdvancedMarkerElement({
      position: { lat: 18.58026396275932, lng: 73.73806906755271 },
      map
    })

    let polygon = new Polygon({
      paths: [{ lat: 18.58026396275932, lng: 73.73806906755271 }, { lat: 18.578818253840677, lng: 73.73436539632988 }, { lat: 18.574220460677935, lng: 73.7374630906234 }],
      map
    })

    // setTimeout(() => {
    //   setInterval(() => {
    //     let zoom = map.getZoom()
    //     if (zoom >= 5) {
    //       map.setZoom(zoom - 1)
    //     }
    //   }, 200)
    // }, 2000)
  });
  return (
    <div id="map"></div>

  )
};

export default GoogleMap;