import { GoogleMap, LoadScript } from "@react-google-maps/api";
import { useState, useRef } from "react";

const mapContainerStyle = {
    width: "100%",
    height: "500px",
};

const defaultCenter = { lat: 18.58025889541215, lng: 73.7380905288356 };

const GoogleMapsCenteredMarker = () => {
    const [markerPosition, setMarkerPosition] = useState(defaultCenter);
    const mapRef = useRef(null);

    const handleCenterChanged = () => {
        if (mapRef.current) {
            const newCenter = mapRef.current.getCenter();
            const newPosition = {
                lat: newCenter.lat(),
                lng: newCenter.lng(),
            };
            setMarkerPosition(newPosition);
        }
    };

    return (
        <LoadScript googleMapsApiKey="AIzaSyAVK2J4mi1vUAYJUXF5-Jq_n_s39LeUbCQ">
            <div style={{ position: "relative", width: "100%", height: "500px" }}>
                <GoogleMap
                    mapContainerStyle={mapContainerStyle}
                    center={defaultCenter}
                    zoom={13}
                    onLoad={(map) => {
                        mapRef.current = map;
                    }}
                    onCenterChanged={handleCenterChanged}
                    options={{ draggable: true }}
                />

                {/* Fixed Center Marker */}
                <div
                    style={{
                        position: "absolute",
                        top: "50%",
                        left: "50%",
                        transform: "translate(-50%, -100%)",
                        zIndex: 1000,
                        pointerEvents: "none",
                    }}
                >
                    <img
                        src="https://maps.gstatic.com/mapfiles/api-3/images/spotlight-poi2_hdpi.png"
                        alt="Marker"
                        width="30"
                    />
                </div>

                {/* Display Coordinates */}
                <div
                    style={{
                        position: "absolute",
                        bottom: "10px",
                        left: "50%",
                        transform: "translateX(-50%)",
                        background: "rgba(255, 255, 255, 0.8)",
                        padding: "5px 10px",
                        borderRadius: "5px",
                    }}
                >
                    Lat: {markerPosition.lat.toFixed(5)}, Lng: {markerPosition.lng.toFixed(5)}
                </div>
            </div>
        </LoadScript>
    );
};

export default GoogleMapsCenteredMarker;