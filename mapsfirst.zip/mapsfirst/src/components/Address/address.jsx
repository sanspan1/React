import React, { useState, useEffect } from "react";

const AddressAutocomplete = () => {
    const [predictions, setPredictions] = useState([]);
    const [query, setQuery] = useState("");
    const [shouldRefetch, setShouldRefetch] = useState(false);
    const [selectedAddress, setSelectedAddress] = useState("");

    useEffect(() => {
        if (!window.google || !window.google.maps) return;
        if (!shouldRefetch) return;

        const autocompleteService = new window.google.maps.places.AutocompleteService();

        if (query.length > 2) {
            autocompleteService.getPlacePredictions(
                { input: query },
                (results, status) => {
                    if (status === window.google.maps.places.PlacesServiceStatus.OK) {
                        setPredictions(results);
                    }
                }
            );
        } else {
            setPredictions([]);
        }

        setShouldRefetch(false);
    }, [shouldRefetch]);

    const handleSelectAddress = (address) => {
        setSelectedAddress(address);
        setQuery(address);
        setPredictions([]);
    };

    return (
        <div className="p-4 w-96 border rounded-lg shadow-md">
            <label className="block text-sm font-medium">Enter Address:</label>
            <input
                type="text"
                value={query}
                onChange={(e) => {
                    setQuery(e.target.value);
                    setShouldRefetch(true);
                }}
                className="w-full p-2 border rounded mt-1"
                placeholder="Type your address..."
            />
            {predictions.length > 0 && (
                <ul className="border bg-white mt-1 rounded shadow">
                    {predictions.map((prediction) => (
                        <li
                            key={prediction.place_id}
                            className="p-2 hover:bg-gray-100 cursor-pointer"
                            onClick={() => handleSelectAddress(prediction.description)}
                        >
                            {prediction.description}
                        </li>
                    ))}
                </ul>
            )}
            <div className="mt-4">
                <label className="block text-sm font-medium">Latitude:</label>
                <div className="w-full p-2 border rounded bg-gray-100 h-10"></div>
            </div>
            <div className="mt-2">
                <label className="block text-sm font-medium">Longitude:</label>
                <div className="w-full p-2 border rounded bg-gray-100 h-10"></div>
            </div>
        </div>
    );
};

export default AddressAutocomplete;
