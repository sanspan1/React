import { useForm } from "react-hook-form";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import './login.css';
import { DevTool } from "@hookform/devtools";

const Login = (props) => {
    console.log(props)
    const { setIsAuthenticated } = props
    const {
        register,
        handleSubmit,
        formState: { errors },
        control
    } = useForm();

    const navigate = useNavigate();

    const onSubmit = async (data) => {
        try {
            const response = await axios.post("http://localhost:3000/login", {
                username: data.username,
                password: data.password,
            });

            if (response.data.success) {
                setIsAuthenticated(true);
                navigate("/home");
            } else {
                alert("Invalid credentials");
            }
        } catch (error) {
            alert("Login failed: " + (error.response?.data?.message || error.message));
        }
    };

    return (
        <div className="login-container">
            <div className="login-box">
                <h2>Welcome to Searce!</h2>
                <h3>Please Login</h3>
                {props.children}
                <form onSubmit={handleSubmit(onSubmit)}>
                    {/* Username Field */}
                    <input
                        {...register("username", { required: "Username is required" })}
                        placeholder="Username"
                    />
                    {errors.username && <p className="error">{errors.username.message}</p>}
                    <br />

                    {/* Password Field */}
                    <input
                        type="password"
                        {...register("password", { required: "Password is required" })}
                        placeholder="Password"
                    />
                    {errors.password && <p className="error">{errors.password.message}</p>}
                    <br />

                    <button type="submit">Login</button>
                </form>
            </div>
            <DevTool control={control} />
        </div>
    );
};

export default Login;






