import { useNavigate } from "react-router-dom";
import logo from "./img.jpg";
import "./header.css";

const Header = ({ setIsAuthenticated }) => {
    const navigate = useNavigate();

    const handleLogout = () => {
        localStorage.removeItem("isAuthenticated"); // Clear authentication
        setIsAuthenticated(false); // Update state
        navigate("/login"); // Redirect to login
    };

    return (
        <div className="header">
            <img src={logo} alt="Logo" className="logo" />
            <button className="logout-button" onClick={handleLogout}>Logout</button>
        </div>
    );
};

export default Header;
