import { Request, Response, NextFunction } from "express";
import User from "../models/User";

export const deleteUser = async (req: Request, res: Response, next: NextFunction) => {
    try {
        const userId = req.params.id; // Get user ID from URL params

        // Check if user exists
        const user = await User.findById(userId);
        if (!user) {
            return res.status(404).json({ message: "User not found" });
        }

        // Delete the user
        await User.findByIdAndDelete(userId);

        res.json({ message: "User deleted successfully" });
    } catch (error) {
        next(error); // Pass errors to the Express error handler
    }
};
