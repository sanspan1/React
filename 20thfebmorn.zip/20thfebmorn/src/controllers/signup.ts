import { Request, Response, NextFunction } from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import User from "../models/User";

export const signup = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
        const { email, password } = req.body;

        // Check if user already exists
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            res.status(400).json({ message: "User already exists" });
            return;
        }


        const hashedPassword = await bcrypt.hash(password, 10);


        const newUser = new User({ email, password: hashedPassword });
        await newUser.save();


        const token = jwt.sign({ userId: newUser._id }, process.env.JWT_SECRET!, { expiresIn: "1h" });

        res.status(201).json({ message: "User registered successfully", token });
    } catch (error) {
        next(error);
    }
};
