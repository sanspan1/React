import { Request, Response, NextFunction } from "express";
import bcrypt from "bcryptjs";
import User from "../models/User";

// Define the expected structure of req.body to prevent TypeScript errors
interface ResetPasswordRequest extends Request {
    body: {
        token: string;
        newPassword: string;
    };
}

export const resetPassword = async (req: ResetPasswordRequest, res: Response, next: NextFunction) => {
    try {
        const { token, newPassword } = req.body;

        // Find user with valid token and check if it's not expired
        const user = await User.findOne({
            resetToken: token,
            resetTokenExpiry: { $gt: new Date() }, // Ensure expiry date is valid
        });

        if (!user) {
            return res.status(400).json({ message: "Invalid or expired token" });
        }

        // Hash the new password
        const hashedPassword = await bcrypt.hash(newPassword, 10);

        // Update password and clear the reset token fields
        user.password = hashedPassword;
        user.resetToken = null as unknown as string;
        user.resetTokenExpiry = null as unknown as Date;
        await user.save();

        res.json({ message: "Password has been reset successfully" });
    } catch (error) {
        next(error);
        // console.error("Error resetting password:", error);
        // res.status(500).json({ message: "Something went wrong", error });
    }
};
