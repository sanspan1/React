import express from "express";
import { signup } from "../controllers/signup";
import { login } from "../controllers/login";
import { validateSignup, validateLogin } from "../middlewares/validate";
import { forgotPassword } from "../controllers/frogotpassword";
import { resetPassword } from "../controllers/resetpassword";
import { deleteUser } from "../controllers/deleteuser";

const router = express.Router();

router.post("/signup", validateSignup, signup);
router.post("/login", validateLogin, login);
// @ts-ignore
router.post("/forgot-password", forgotPassword);
// @ts-ignore
router.post("/reset-password", resetPassword);
// @ts-ignore
router.delete("/delete/:id", deleteUser);

export default router;
