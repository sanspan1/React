import { Request, Response, NextFunction } from "express";
import { signupSchema, loginSchema } from "../schemas/authSchema";

export const validateSignup = (req: Request, res: Response, next: NextFunction) => {
    try {
        signupSchema.parse(req.body);
        next();
    } catch (error) {
        res.status(400).json({ message: "Validation failed", error });
    }
};

export const validateLogin = (req: Request, res: Response, next: NextFunction) => {
    try {
        loginSchema.parse(req.body);
        next();
    } catch (error) {
        res.status(400).json({ message: "Validation failed", error });
    }
};


