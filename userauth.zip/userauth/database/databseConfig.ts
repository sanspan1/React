import mongoose from "mongoose";

const databaseConfig = (): void => {

    mongoose.connect(process.env.MONGO_URI as string)
        .then(() => {
            console.log("Connected to database successfully!");
        })
        .catch((err: Error) => {
            console.error("Connection to database failed.", err);
            throw err;
        });
}

export default databaseConfig;
