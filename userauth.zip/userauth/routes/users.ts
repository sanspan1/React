import express from "express";
import controller from "../controller/users";

const router = express.Router();

// @ts-ignore
router.post("/signup", controller.addUser)
// @ts-ignore
router.post("/login", controller.login)

export default router;