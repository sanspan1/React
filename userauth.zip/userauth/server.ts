import express from "express";
import cors from "cors";
import databaseConfig from "./database/databseConfig";
import router from "./routes/users";
import { config } from "dotenv"

const app = express();

app.use(express.json());
app.use(cors());
config({
    path: "./config.env"
})

databaseConfig();


app.use("/user", router)

app.listen(process.env.PORT, () => {
    console.log(`Server is listening on PORT: ${process.env.PORT}`)
})
